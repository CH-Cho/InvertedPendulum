******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 3.0
* @date    08-December-2025
* @brief   MB1367 Bill of materials package
******************************************************************************
* COPYRIGHT(c) 2025 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* History
========================
* 3.0 - 08-Dec-2025
------------------------
    + Add D01 BOM with new part references:
        - Several part references have been updated due to obsolescence, such as the STMICROELECTRONICS ESDALC6V1-1U2 diode, which has been replaced by the STMICROELECTRONICS ESDZL5-1F4 diode, with an impact on the PCB.
------------------------
* 2.2 - 05-June-2024
------------------------
    + Add missing BOM C04

* 2.1 - 9-February-2022
------------------------
    + Updated all BOM to rev C05

* 2.1 - 9-February-2022
------------------------
    + Updated all BOM to rev C05

* 2.0 - 4-December-2020
------------------------
    + Added MB1367-G491RE-C04_BOM.xlsx variant with STM32G491RET6U
 
* 1.0 - 17-September-2019
------------------------
    + First official release.
	
******************* (C) COPYRIGHT 2025 STMicroelectronics *****END OF FILE
